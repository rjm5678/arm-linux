#ifndef EXCEPTION_H
#define EXCEPTION_H

void print_und_exception(char* a, char* b);
void print_swi_exception(char* a, char* b);
void print_swi_val(unsigned int *pswi);

#endif
