#ifndef INIT_H
#define INIT_H

void Bank0_tacc_init(int val);
void interrput_init();
void key_eint_init();
void led_init();


#endif
