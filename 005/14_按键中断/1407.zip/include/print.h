#ifndef PRINT_H
#define PRINT_H

int putchar(int c);
int getchar();
int puts(const char *s);
void print_hex(int val);
void print123();
void printABC();

#endif
