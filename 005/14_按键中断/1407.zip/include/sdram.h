#ifndef SDRAM_H
#define SDRAM_H

void sdram_init();
int sdram_test();


#endif
