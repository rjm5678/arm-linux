实现流水灯LED1->LED2->LED1

# 修改系统时钟
FCLK = 400MHZ
HCLK = 100MHZ
PCLK = 50MH

//改变tacc的时间

//配置SDRAM

//重定位

//bss段的清零

//链接脚本和重定位的改进

//c语言实现整段代码的重定位

//故意实现und异常

//故意实现swi异常

按键中断点灯 和 整理文件